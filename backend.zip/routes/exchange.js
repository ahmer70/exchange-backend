const express = require("express");
const router = express.Router();
const axios = require("axios");

const fixer = require("fixer-api");
const accessKey = process.env.accessKey
fixer.set({ accessKey });

const { JWT } = require("../middlewares/jwtAuth");


router.get('/lookup', JWT, async (req, res) => {
    try {
        const countryName = req.query.name;
        const countryInfo = await axios.get(`https://restcountries.com/v2/name/${countryName}`);
        const exchangeRates = await fixer.latest(({ base: "EUR", symbols: [countryInfo.data[0].currencies[0].code] }));
        const result = {
            fullName: countryInfo.data[0].name,
            population: countryInfo.data[0].population,
            currencies: {
                name: countryInfo.data[0].currencies[0].name,
                code: countryInfo.data[0].currencies[0].code,
                exchangeRateToEUR: exchangeRates.rates[countryInfo.data[0].currencies[0].code],
            },
        };
        console.log("result", result)
        res.json(result);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'An error occurred' });
    }
});
module.exports = router;
